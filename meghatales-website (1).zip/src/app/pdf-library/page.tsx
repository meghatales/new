import PdfLibrary from "@/components/PdfLibrary";

export default function PdfLibraryPage() {
  return (
    <main className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold mb-8 text-center">PDF Library</h1>
      <PdfLibrary />
    </main>
  );
}

